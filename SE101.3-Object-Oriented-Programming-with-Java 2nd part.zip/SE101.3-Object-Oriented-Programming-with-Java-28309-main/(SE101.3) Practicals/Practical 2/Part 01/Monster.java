public class Monster extends Item 
{
    // Constructor for Monster class
    public Monster(int location, String description) {
        // Call the superclass constructor using 'super'
        super(location, description);
    }
}

