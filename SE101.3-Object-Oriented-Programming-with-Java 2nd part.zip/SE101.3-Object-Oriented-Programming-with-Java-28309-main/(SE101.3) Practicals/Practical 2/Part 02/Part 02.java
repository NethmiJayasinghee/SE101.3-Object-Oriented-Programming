//1. 
   //Answer: b) super

//3. 
   //Answer: b) private

//4. 
   //Answer: b) Packages

//5. 
   //Answer: c) import pkg.*

//6. 
   //Answer: c) charAt()

//7
   //Answer: d) length()
