public class MyDetails {
    public static void main(String[] args) {
        System.out.println("Your Name"); // Replace "Your Name" with your actual name
        System.out.println("Your Degree Programme"); // Replace "Your Degree Programme" with your actual degree program
    }
}

//Your Name
//Your Degree Programme
