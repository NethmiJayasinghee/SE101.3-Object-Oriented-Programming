public class Loop 
{
    public static void main(String[] args) {
        int i;
        for (i=0;i<=4;i++) 
        {
            System.out.println("Executing Loop " + i);
           
        }
    }
}
