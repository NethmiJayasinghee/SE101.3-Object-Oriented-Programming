abstract class Container {
  public abstract double volume();
}
