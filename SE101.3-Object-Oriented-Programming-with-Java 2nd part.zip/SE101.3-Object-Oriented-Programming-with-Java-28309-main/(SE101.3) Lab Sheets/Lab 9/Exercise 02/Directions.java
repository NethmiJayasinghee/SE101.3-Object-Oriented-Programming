public enum Directions {
  UP,
  DOWN,
  LEFT,
  RIGHT
}