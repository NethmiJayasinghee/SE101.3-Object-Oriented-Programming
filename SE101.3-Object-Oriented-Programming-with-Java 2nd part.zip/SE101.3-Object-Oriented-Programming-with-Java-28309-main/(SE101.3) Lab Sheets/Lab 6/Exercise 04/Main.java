public class Main {
  public static void main(String[] args) {
    Circle c1 = new Circle(7);
    c1.calculateArea();
    c1.display();

    Rectangle r1 = new Rectangle(4, 5);
    r1.calculateArea();
    r1.display();
  }
}