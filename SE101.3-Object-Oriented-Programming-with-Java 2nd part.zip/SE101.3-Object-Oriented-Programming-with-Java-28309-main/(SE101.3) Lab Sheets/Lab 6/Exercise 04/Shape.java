abstract class Shape {
  abstract double calculateArea();

  void display() {}
}
