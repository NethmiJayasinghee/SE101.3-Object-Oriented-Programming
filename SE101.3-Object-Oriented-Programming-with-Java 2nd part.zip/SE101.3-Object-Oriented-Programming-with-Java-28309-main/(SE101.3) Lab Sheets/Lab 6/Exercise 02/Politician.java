public class Politician implements Speaker {
  @Override
  public void speak() {}
}
