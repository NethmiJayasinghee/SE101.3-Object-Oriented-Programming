public class Main {
  public static void main(String[] args) {
    Priest priest = new Priest();
    priest.speak();

    Lecturer lecturer = new Lecturer();
    lecturer.speak();

    Politician politicial = new Politician();
    politicial.speak();
  }
}