public interface Speaker {
  void speak();
}
