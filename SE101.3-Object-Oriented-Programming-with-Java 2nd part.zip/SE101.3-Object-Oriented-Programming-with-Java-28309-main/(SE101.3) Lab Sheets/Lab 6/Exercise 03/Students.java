final class Student {
  final int marks = 100;

  final void display() {}
}