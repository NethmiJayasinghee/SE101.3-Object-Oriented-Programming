//Student class cannot be utilised by another subclass that attempts to inherit it since it is declared with the final modifier.

// ERROR:
public class Undergraduate extends Student {}